database_path = "BotDataBase.db"
token = "put your bot token here"
owner = 0 #İf you want to set someone as owner, you can put his/her discord id instead of 0
discord_link = "https://discord.gg/ZdFuK3KN7f"